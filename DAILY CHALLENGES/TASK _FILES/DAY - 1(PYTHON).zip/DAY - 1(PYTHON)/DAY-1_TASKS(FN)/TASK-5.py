#TASK-5: EXTRACT ONE'S PLACE DIGIT:

num = int(input("Enter a number: "))
print("One's place digit:", num % 10)
