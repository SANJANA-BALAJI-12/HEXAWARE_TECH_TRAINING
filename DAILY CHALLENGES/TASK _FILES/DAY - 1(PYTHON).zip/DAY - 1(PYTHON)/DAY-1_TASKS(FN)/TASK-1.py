#TASK-1 CONVERT CELSIUS TO FAHRENHEIT:


celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 9/5)+32
print("Temperature in Fahrenheit:%.2f" % fahrenheit)

