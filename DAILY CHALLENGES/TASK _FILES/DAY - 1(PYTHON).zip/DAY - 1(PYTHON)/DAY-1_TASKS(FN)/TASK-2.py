#TASK-2: AREA OF CUBE:

side = float(input("Enter the side length of the cube: "))
area = 6 * (side ** 2)
print("Surface area of the cube:", area)
