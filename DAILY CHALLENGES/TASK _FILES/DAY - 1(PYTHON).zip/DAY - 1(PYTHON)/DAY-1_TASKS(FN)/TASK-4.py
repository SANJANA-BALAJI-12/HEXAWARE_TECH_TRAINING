#TASK-4: HEX,OCTAL AND SQUARE ROOT:

import math

num = int(input("Enter a number: "))

print("Hexadecimal:", hex(num))
print("Octal:", oct(num))
print("Square root:", math.sqrt(num))
