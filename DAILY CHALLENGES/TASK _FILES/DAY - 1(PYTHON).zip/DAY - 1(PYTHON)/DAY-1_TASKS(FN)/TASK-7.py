#TASK-7: VOLUME OF SPHERE

import math

radius = float(input("Enter the radius of the sphere: "))
volume = (4 / 3) * math.pi * (radius ** 3)
print("Volume of the sphere:", volume)
